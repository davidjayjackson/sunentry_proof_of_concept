from django.urls import path, include
from . import views

urlpatterns = [
    path("", views.entry, name="entry"),
    path("summary/", views.summary, name="summary"),
    path("accounts/", include("django.contrib.auth.urls")),
]
