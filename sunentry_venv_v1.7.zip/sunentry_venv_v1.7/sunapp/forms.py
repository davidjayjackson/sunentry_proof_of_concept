from django import forms

SEEING_CHOICES = [("E","E"),("G","G"),("F","F"),("P","P")]

class EntryRowForm(forms.Form):
    year = forms.IntegerField(min_value=1900, max_value=3000, initial=2026)
    month = forms.IntegerField(min_value=1, max_value=12, initial=1)
    day = forms.IntegerField(min_value=1, max_value=31, initial=1)
    hour = forms.IntegerField(min_value=0, max_value=23, initial=0)
    minute = forms.IntegerField(min_value=0, max_value=59, initial=0)

    see = forms.ChoiceField(choices=SEEING_CHOICES, initial="G")
    g = forms.IntegerField(min_value=0, initial=0)
    s = forms.IntegerField(min_value=0, initial=0)
    w = forms.IntegerField(
    min_value=0,
    required=False,
    widget=forms.NumberInput(attrs={"readonly": "readonly"}))

    remarks = forms.CharField(required=False, max_length=250)

class UploadForm(forms.Form):
    inst = forms.CharField(required=False, max_length=15)
    method = forms.CharField(required=False, max_length=15)
