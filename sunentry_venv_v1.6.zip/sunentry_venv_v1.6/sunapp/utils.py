from __future__ import annotations

MONTHS = ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]

def monthyr_str(year: int, month: int) -> str:
    return f"{MONTHS[month-1]} {year}"

def ut_hhmm(hour: int, minute: int) -> str:
    return f"{hour:02d}{minute:02d}"

def jd_text_for_date(year: int, month: int, day: int) -> str:
    # Gregorian -> JDN
    a = (14 - month) // 12
    y = year + 4800 - a
    m = month + 12*a - 3
    jdn = day + ((153*m + 2)//5) + 365*y + (y//4) - (y//100) + (y//400) - 32045
    # JD at 0h UT is jdn - 0.5; store integer at noon -> add 0.5
    return str(int((jdn - 0.5) + 0.5))

def exclude_from_index(inst: str, method: str) -> int:
    if inst == "SDO-HMI" or method == "CCD":
        return 1
    return 0
