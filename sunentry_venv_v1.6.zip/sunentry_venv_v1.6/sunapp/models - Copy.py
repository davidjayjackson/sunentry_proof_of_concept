from django.db import models


class SunData(models.Model):
    uid = models.BigAutoField(primary_key=True, db_column="uid")
    date = models.CharField(max_length=12, db_column="date")
    monthyr = models.CharField(max_length=8, db_column="monthyr")
    day = models.IntegerField(db_column="day")
    see = models.CharField(max_length=3, db_column="see")
    ut = models.CharField(max_length=5, db_column="UT")
    g = models.IntegerField(db_column="g")
    s = models.IntegerField(db_column="s")
    w = models.IntegerField(db_column="W")
    ng = models.IntegerField(db_column="ng")
    sg = models.IntegerField(db_column="sg")
    ns = models.IntegerField(db_column="ns")
    ss = models.IntegerField(db_column="ss")
    cg = models.IntegerField(db_column="cg")
    cs = models.IntegerField(db_column="cs")
    obs = models.CharField(max_length=10, db_column="Obs")
    remarks = models.CharField(max_length=250, db_column="Remarks")
    revised = models.IntegerField(db_column="revised")
    published = models.IntegerField(db_column="published")
    exclude_from_index = models.IntegerField(db_column="exclude_from_index")
    header_id = models.IntegerField(db_column="header_id")

    class Meta:
        managed = False
        db_table = "sun_data"


class SunHeader(models.Model):
    id = models.BigAutoField(primary_key=True, db_column="id")
    monthyr = models.CharField(max_length=8, db_column="monthyr")
    obs = models.CharField(max_length=20, db_column="Obs")
    name = models.CharField(max_length=100, db_column="name")
    add1 = models.CharField(max_length=50, db_column="add1")
    add2 = models.CharField(max_length=50, db_column="add2")
    city = models.CharField(max_length=50, db_column="city")
    state_prov = models.CharField(max_length=50, db_column="state_prov")
    zip = models.CharField(max_length=20, db_column="zip")
    country = models.CharField(max_length=20, db_column="country")
    phone = models.CharField(max_length=15, db_column="phone")
    email = models.CharField(max_length=50, db_column="email")
    method = models.CharField(max_length=15, db_column="method")
    inst = models.CharField(max_length=15, db_column="inst")
    aperture = models.CharField(max_length=10, db_column="aperture")
    focal_length = models.CharField(max_length=10, db_column="focal_length")
    focal_length_type = models.CharField(max_length=10, db_column="focal_length_type")
    eyepiece = models.CharField(max_length=10, db_column="eyepiece")
    magnification = models.CharField(max_length=10, db_column="magnification")
    filter = models.CharField(max_length=10, db_column="filter")
    resolution = models.CharField(max_length=10, db_column="resolution")
    updated = models.DateTimeField(db_column="updated")

    class Meta:
        managed = False
        db_table = "sun_header"


class SunObsConst(models.Model):
    unique_id = models.BigAutoField(primary_key=True, db_column="unique_id")
    obs = models.CharField(max_length=20, db_column="Obs")
    aavso_obscode = models.CharField(
        max_length=10, db_column="AAVSO_obscode", null=True, blank=True
    )
    sidc_submitter = models.IntegerField(
        db_column="SIDC_submitter", null=True, blank=True
    )

    class Meta:
        managed = False
        db_table = "sun_obsconst"
