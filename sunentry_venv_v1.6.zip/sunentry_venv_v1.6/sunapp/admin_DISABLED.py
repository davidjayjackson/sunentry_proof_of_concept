from django.contrib import admin
from .models import SunData, SunHeader, SunObsConst

@admin.register(SunData)
class SunDataAdmin(admin.ModelAdmin):
    list_display = ("uid","obs","date","ut","g","s","w","revised","published","exclude_from_index","monthyr","day")
    list_filter = ("obs","monthyr","revised","published","exclude_from_index")
    search_fields = ("obs","date","ut","remarks")

@admin.register(SunHeader)
class SunHeaderAdmin(admin.ModelAdmin):
    list_display = ("header_id","obs","monthyr","updated","name","email","inst","method")
    list_filter = ("obs","monthyr")

@admin.register(SunObsConst)
class SunObsConstAdmin(admin.ModelAdmin):
    list_display = ("unique_id","obs","aavso_obscode","sidc_submitter")
    search_fields = ("obs","aavso_obscode")
