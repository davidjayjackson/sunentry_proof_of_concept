Missing Columns:
ng = North Groups
sg  = South Groups
ns = North Sports
ss = South Spots
cg = ?
cs = ?