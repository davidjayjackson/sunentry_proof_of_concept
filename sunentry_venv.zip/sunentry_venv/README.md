# SunEntry Django (MySQL existing tables)

This project is a Django web rewrite of the Java Swing **SunEntry** workflow, using the **existing**
MySQL tables in schema `solar` (`sun_header`, `sun_data`, `sun_obsconst`).

## Quick start

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
source .venv/bin/activate

pip install -r requirements.txt

# Set DB env vars (examples)
export SUN_DB_HOST=localhost
export SUN_DB_NAME=solar
export SUN_DB_USER=solarobs
export SUN_DB_PASSWORD=your_password
export SUN_DB_PORT=3306

python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```

Open:
- http://127.0.0.1:8000/accounts/login/
- then http://127.0.0.1:8000/

## Notes
- Models are `managed = False` (Django will not modify tables).
- `sun_data.date` is stored as **text** (e.g. `2456049`), matching the existing table.
- Duplicate logic is based on `(Obs, date, UT, revised=0)` so multiple UT entries on the same date are allowed.
