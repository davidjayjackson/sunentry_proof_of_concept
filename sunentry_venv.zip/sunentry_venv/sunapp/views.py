from __future__ import annotations
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.http import HttpRequest, HttpResponse
from django.shortcuts import redirect, render
from django.db.models import Count

from .forms import EntryRowForm, UploadForm
from .models import SunData
from .services import DraftRow, upload_draft
from .utils import jd_text_for_date, monthyr_str, ut_hhmm

SESSION_KEY = "sunentry_draft_rows"

def _get_draft(request: HttpRequest) -> list[dict]:
    return request.session.get(SESSION_KEY, [])

def _set_draft(request: HttpRequest, rows: list[dict]) -> None:
    request.session[SESSION_KEY] = rows
    request.session.modified = True

@login_required
def entry(request: HttpRequest) -> HttpResponse:
    draft = _get_draft(request)

    if request.method == "POST":
        action = request.POST.get("action")

        if action == "add":
            form = EntryRowForm(request.POST)
            if form.is_valid():
                d = form.cleaned_data
                d["jd"] = jd_text_for_date(d["year"], d["month"], d["day"])
                d["ut"] = ut_hhmm(d["hour"], d["minute"])
                d["monthyr"] = monthyr_str(d["year"], d["month"])
                draft.append(d)
                _set_draft(request, draft)
                messages.success(request, "Added row to draft list.")
            else:
                messages.error(request, "Please correct the entry fields.")
            return redirect("entry")

        if action == "remove":
            idxs = request.POST.getlist("row_idx")
            idxs_int = sorted({int(i) for i in idxs if str(i).isdigit()}, reverse=True)
            for i in idxs_int:
                if 0 <= i < len(draft):
                    draft.pop(i)
            _set_draft(request, draft)
            return redirect("entry")

        if action == "clear":
            _set_draft(request, [])
            return redirect("entry")

        if action == "upload":
            up = UploadForm(request.POST)
            if not up.is_valid():
                messages.error(request, "Invalid upload options.")
                return redirect("entry")

            rows = [DraftRow(**{k: r[k] for k in DraftRow.__annotations__.keys() if k in r}) for r in draft]
            try:
                res = upload_draft(
                    obs=request.user.username,
                    draft_rows=rows,
                    inst=up.cleaned_data.get("inst",""),
                    method=up.cleaned_data.get("method",""),
                )
                messages.success(request, f"Uploaded {res['submitted']} row(s). Updated {res['updated']} duplicate(s). Total this month ({res['monthyr']}): {res['total_month']}.")
                _set_draft(request, [])
            except Exception as e:
                messages.error(request, str(e))
            return redirect("entry")

    recent = SunData.objects.filter(obs=request.user.username, revised=0).order_by("-uid")[:50]
    return render(request, "sunapp/entry.html", {"row_form": EntryRowForm(), "upload_form": UploadForm(), "draft_rows": draft, "recent_rows": recent})

@login_required
def summary(request: HttpRequest) -> HttpResponse:
    qs = SunData.objects.filter(obs=request.user.username, revised=0)
    month_counts = qs.values("monthyr").annotate(n=Count("uid")).order_by("-monthyr")
    return render(request, "sunapp/summary.html", {"month_counts": month_counts})
