from django.urls import path
from . import views

urlpatterns = [
    path("", views.entry, name="entry"),
    path("summary/", views.summary, name="summary"),
]
