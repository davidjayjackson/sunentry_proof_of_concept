from __future__ import annotations
from dataclasses import dataclass
from django.db import transaction
from .models import SunData, SunHeader
from .utils import jd_text_for_date, monthyr_str, ut_hhmm, exclude_from_index

@dataclass(frozen=True)
class DraftRow:
    year: int
    month: int
    day: int
    hour: int
    minute: int
    see: str
    g: int
    s: int
    w: int
    remarks: str = ""

def _latest_header_id_for_obs(obs: str) -> int:
    header = SunHeader.objects.filter(obs=obs).order_by("-updated","-header_id").first()
    if not header:
        raise ValueError(f"Missing header record for observer '{obs}'.")
    return int(header.header_id)

@transaction.atomic
def upload_draft(*, obs: str, draft_rows: list[DraftRow], inst: str = "", method: str = "") -> dict:
    submitted = 0
    updated = 0
    if not draft_rows:
        return {"submitted": 0, "updated": 0, "monthyr": "", "total_month": 0}

    my = monthyr_str(draft_rows[0].year, draft_rows[0].month)
    header_id = _latest_header_id_for_obs(obs)

    for r in draft_rows:
        date_txt = jd_text_for_date(r.year, r.month, r.day)
        ut_txt = ut_hhmm(r.hour, r.minute)

        existing = SunData.objects.filter(obs=obs, date=date_txt, ut=ut_txt, revised=0).first()
        if existing:
            existing.revised = 1
            existing.save(update_fields=["revised"])
            updated += 1

        SunData.objects.create(
            date=date_txt,
            monthyr=my,
            day=r.day,
            see=r.see,
            ut=ut_txt,
            g=r.g,
            s=r.s,
            w=r.w,
            ng=0, sg=0, ns=0, ss=0, cg=0, cs=0,
            obs=obs,
            remarks=r.remarks or "",
            revised=0,
            published=0,
            exclude_from_index=exclude_from_index(inst, method),
            header_id=header_id,
        )
        submitted += 1

    total_month = SunData.objects.filter(obs=obs, monthyr=my, revised=0).count()
    return {"submitted": submitted, "updated": updated, "monthyr": my, "total_month": total_month}
